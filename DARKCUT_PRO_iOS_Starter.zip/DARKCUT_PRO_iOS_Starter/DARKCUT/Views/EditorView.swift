import SwiftUI
import PhotosUI
import AVKit

struct EditorView: View {
    @EnvironmentObject private var project: EditorProject
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var player = AVPlayer()
    @State private var showExportInfo = false
    @State private var importError: String?
    @State private var toastMessage: String?

    private let bg = Color(red: 0.035, green: 0.043, blue: 0.063)
    private let panel = Color(red: 0.075, green: 0.09, blue: 0.125)
    private let purple = Color(red: 0.55, green: 0.48, blue: 1)

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView {
                VStack(spacing: 14) {
                    preview
                    transport
                    timeline
                    inspector
                    toolShelf
                }
                .padding(14)
            }
        }
        .background(bg.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .onChange(of: selectedItems) { _, items in
            Task { await importItems(items) }
        }
        .alert("Импорт не выполнен", isPresented: Binding(
            get: { importError != nil },
            set: { if !$0 { importError = nil } }
        )) {
            Button("OK", role: .cancel) { importError = nil }
        } message: {
            Text(importError ?? "Неизвестная ошибка")
        }
        .overlay(alignment: .bottom) {
            if let toastMessage {
                Text(toastMessage).font(.system(size: 11, weight: .medium))
                    .padding(12).background(.ultraThinMaterial, in: Capsule())
                    .padding(.bottom, 18).transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .alert("Экспорт", isPresented: $showExportInfo) {
            Button("Понятно", role: .cancel) {}
        } message: {
            Text("Экспортный движок будет подключён после реализации композиции дорожек. Сейчас это каркас интерфейса, а не готовый рендерер.")
        }
    }

    private var header: some View {
        HStack {
            HStack(spacing: 9) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10).fill(LinearGradient(colors: [purple, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Text("D").font(.system(size: 19, weight: .black))
                }.frame(width: 34, height: 34)
                VStack(alignment: .leading, spacing: 1) {
                    Text("DARKCUT").font(.system(size: 13, weight: .black, design: .rounded)).tracking(2)
                    Text("PRO MOBILE EDITOR").font(.system(size: 8, weight: .semibold)).tracking(1.4).foregroundStyle(.secondary)
                }
            }
            Spacer()
            Button { showExportInfo = true } label: {
                Text("ЭКСПОРТ").font(.system(size: 10, weight: .bold))
                    .padding(.horizontal, 14).padding(.vertical, 10)
                    .background(purple.gradient, in: RoundedRectangle(cornerRadius: 9))
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 11)
        .background(.black.opacity(0.2))
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: 9) {
            sectionHeader("ПРЕДПРОСМОТР", trailing: "9:16 · PRO")
            ZStack {
                RoundedRectangle(cornerRadius: 13).fill(.black)
                if let clip = project.clips.first(where: { $0.kind == .video || $0.kind == .photo }),
                   let url = clip.sourceURL {
                    if clip.kind == .video {
                        VideoPlayer(player: player)
                            .onAppear { player.replaceCurrentItem(with: AVPlayerItem(url: url)) }
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                    } else {
                        AsyncImage(url: url) { phase in
                            if let image = phase.image { image.resizable().scaledToFit() }
                            else { ProgressView() }
                        }
                    }
                } else {
                    VStack(spacing: 9) {
                        Image(systemName: "play.circle.fill").font(.system(size: 42)).foregroundStyle(purple)
                        Text("Ваш проект начинается здесь").font(.system(size: 13, weight: .semibold))
                        Text("Добавьте видео или фото").font(.system(size: 10)).foregroundStyle(.secondary)
                    }
                }
            }
            .aspectRatio(9/16, contentMode: .fit)
            .frame(maxHeight: 360)
            .frame(maxWidth: .infinity)
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.08)))
        }
        .padding(12).background(panel, in: RoundedRectangle(cornerRadius: 14))
    }

    private var transport: some View {
        HStack {
            Button { player.play() } label: {
                Image(systemName: "play.fill").frame(width: 34, height: 34)
                    .background(purple, in: Circle())
            }
            Text(time(project.playhead) + " / " + time(project.duration))
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
            Spacer()
            Text(project.aspectRatio).font(.system(size: 10, weight: .semibold))
                .padding(7).background(panel, in: RoundedRectangle(cornerRadius: 7))
        }
    }

    private var timeline: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                sectionHeader("ТАЙМЛАЙН", trailing: "\(project.clips.count) клипов")
                Spacer()
                PhotosPicker(selection: $selectedItems, maxSelectionCount: 10,
                             matching: .any(of: [.videos, .images])) {
                    Label("＋ МЕДИА", systemImage: "photo").font(.system(size: 9, weight: .bold))
                        .padding(9).background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                }
            }
            trackRow(label: "V1", kind: .video)
            trackRow(label: "T", kind: .text)
            trackRow(label: "A1", kind: .audio)
            HStack {
                Text("ПОЗИЦИЯ").font(.system(size: 8, weight: .bold)).foregroundStyle(.secondary)
                Slider(value: $project.playhead, in: 0...max(project.duration, 1))
                    .tint(purple)
                Text(time(project.playhead)).font(.system(size: 9, design: .monospaced))
            }
        }
        .padding(12).background(panel, in: RoundedRectangle(cornerRadius: 14))
    }

    private func trackRow(label: String, kind: ClipKind) -> some View {
        HStack(spacing: 7) {
            Text(label).font(.system(size: 9, weight: .bold)).foregroundStyle(.secondary).frame(width: 23)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(project.clips.filter { $0.kind == kind || (kind == .video && $0.kind == .photo) }) { clip in
                        Button { project.selectedClipID = clip.id } label: {
                            Text(clip.name).font(.system(size: 9, weight: .semibold))
                                .lineLimit(1).padding(.horizontal, 9).frame(height: 34)
                                .background(clip.id == project.selectedClipID ? purple : trackColor(kind), in: RoundedRectangle(cornerRadius: 5))
                                .overlay(RoundedRectangle(cornerRadius: 5).stroke(.white.opacity(0.2)))
                        }
                    }
                    if project.clips.filter({ $0.kind == kind }).isEmpty {
                        Text(kind == .video ? "Импортируйте видео" : kind == .text ? "Текстовые слои" : "Аудиодорожка")
                            .font(.system(size: 9)).foregroundStyle(.tertiary).padding(.leading, 6)
                    }
                }
            }
        }
    }

    private var inspector: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                sectionHeader("ИНСПЕКТОР", trailing: project.selectedClip?.name ?? "Ничего не выбрано")
                Spacer()
                Button("УДАЛИТЬ") { project.deleteSelected() }
                    .font(.system(size: 9, weight: .bold)).foregroundStyle(.red)
                    .disabled(project.selectedClip == nil)
            }
            if let clip = project.selectedClip {
                HStack {
                    valueField("НАЧАЛО", value: clip.sourceIn)
                    valueField("КОНЕЦ", value: clip.sourceOut)
                    valueField("СКОРОСТЬ", value: clip.speed)
                }
                HStack {
                    Button("РАЗДЕЛИТЬ ПО КУРСОРУ") { project.splitSelectedAtPlayhead() }
                    Button("СБРОСИТЬ СКОРОСТЬ") { project.updateSelected { $0.speed = 1 } }
                }
                .font(.system(size: 9, weight: .bold))
                .buttonStyle(.bordered)
            } else {
                Text("Выберите клип на таймлайне, чтобы изменить параметры.")
                    .font(.system(size: 10)).foregroundStyle(.secondary)
            }
        }
        .padding(12).background(panel, in: RoundedRectangle(cornerRadius: 14))
    }

    private var toolShelf: some View {
        HStack {
            tool("textformat", "Текст") { addText() }
            Spacer()
            tool("waveform", "Аудио") { toast("Импорт аудио добавим следующим модулем") }
            Spacer()
            tool("scissors", "Разделить") { project.splitSelectedAtPlayhead() }
            Spacer()
            tool("person.crop.rectangle", "AI фон") { toast("Модуль Vision segmentation подготовлен в архитектуре") }
            Spacer()
            tool("sparkles", "Фильтры") { toast("Модуль фильтров будет следующим этапом") }
        }
        .padding(.horizontal, 8).padding(.vertical, 12)
        .background(panel, in: RoundedRectangle(cornerRadius: 14))
    }

    private func tool(_ icon: String, _ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 17))
                Text(title).font(.system(size: 8, weight: .medium))
            }.foregroundStyle(.secondary)
        }
    }

    private func toast(_ message: String) {
        withAnimation { toastMessage = message }
        Task {
            try? await Task.sleep(for: .seconds(2.2))
            withAnimation { toastMessage = nil }
        }
    }

    private func addText() {
        let clip = EditorClip(name: "Текстовый слой", kind: .text, sourceURL: nil,
                              timelineStart: project.playhead, sourceIn: 0, sourceOut: 5,
                              text: "Ваш текст")
        project.add(clip)
    }

    private func importItems(_ items: [PhotosPickerItem]) async {
        for item in items {
            do {
                let imported = try await MediaImportService.importItem(item)
                let clip = EditorClip(name: imported.url.lastPathComponent,
                                      kind: imported.kind, sourceURL: imported.url,
                                      timelineStart: project.duration, sourceIn: 0,
                                      sourceOut: max(imported.duration, 0.1))
                await MainActor.run { project.add(clip) }
            } catch {
                await MainActor.run { importError = error.localizedDescription }
            }
        }
        await MainActor.run { selectedItems = [] }
    }

    private func sectionHeader(_ title: String, trailing: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.system(size: 9, weight: .black)).tracking(1.2)
            Text(trailing).font(.system(size: 8)).foregroundStyle(.secondary)
        }
    }

    private func valueField(_ title: String, value: Double) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 7, weight: .bold)).foregroundStyle(.secondary)
            Text(String(format: "%.2f", value)).font(.system(size: 11, design: .monospaced))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(8).background(.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 6))
        }
    }

    private func trackColor(_ kind: ClipKind) -> Color {
        switch kind {
        case .video, .photo: return Color.indigo.opacity(0.65)
        case .audio: return Color.teal.opacity(0.65)
        case .text: return Color.orange.opacity(0.65)
        }
    }

    private func time(_ value: Double) -> String {
        let v = max(0, value)
        return String(format: "%02d:%05.2f", Int(v) / 60, v.truncatingRemainder(dividingBy: 60))
    }
}
