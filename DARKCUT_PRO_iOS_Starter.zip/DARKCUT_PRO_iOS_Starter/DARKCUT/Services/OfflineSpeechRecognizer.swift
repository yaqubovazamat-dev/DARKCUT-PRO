import Foundation

/// Interface boundary for a fully offline multilingual recognizer.
/// Apple Speech is not assumed to support Uzbek offline.
/// Planned implementation: bundle/download a licensed Whisper multilingual model
/// and run it locally via whisper.cpp or a Core ML conversion.
struct WordTimestamp: Identifiable {
    let id = UUID()
    var text: String
    var start: Double
    var end: Double
}

protocol OfflineSpeechRecognizing {
    func transcribeAudio(at url: URL) async throws -> [WordTimestamp]
}

enum OfflineASRError: Error {
    case modelNotInstalled
    case unsupportedAudio
}

final class OfflineUzbekSpeechRecognizer: OfflineSpeechRecognizing {
    func transcribeAudio(at url: URL) async throws -> [WordTimestamp] {
        // Deliberately fails closed until a real local model is integrated.
        // Do not silently fall back to a cloud API: user selected offline-only AI.
        throw OfflineASRError.modelNotInstalled
    }
}
