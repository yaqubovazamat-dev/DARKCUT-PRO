import Foundation
import Vision
import CoreImage
import ImageIO

/// Offline person-mask generation for a single frame.
/// For video, call this per frame with throttling/caching; full-resolution real-time
/// segmentation can be expensive and must be profiled on the target iPhone.
final class PersonSegmentationService {
    private let context = CIContext()

    func makePersonMask(from imageURL: URL) throws -> CIImage? {
        let request = VNGeneratePersonSegmentationRequest()
        request.qualityLevel = .balanced
        request.outputPixelFormat = kCVPixelFormatType_OneComponent8

        let handler = VNImageRequestHandler(url: imageURL)
        try handler.perform([request])

        guard let observation = request.results?.first else { return nil }
        return CIImage(cvPixelBuffer: observation.pixelBuffer)
    }
}
