import Foundation
import PhotosUI
import AVFoundation
import UniformTypeIdentifiers

enum MediaImportError: Error {
    case unsupportedAsset
    case unableToCopy
}

struct ImportedMedia {
    let url: URL
    let kind: ClipKind
    let duration: Double
}

enum MediaImportService {
    static func importItem(_ item: PhotosPickerItem) async throws -> ImportedMedia {
        if let movie = try await item.loadTransferable(type: MovieTransfer.self) {
            let asset = AVURLAsset(url: movie.url)
            let duration = (try? await asset.load(.duration).seconds) ?? 0
            return ImportedMedia(url: movie.url, kind: .video, duration: duration)
        }

        if let data = try await item.loadTransferable(type: Data.self) {
            let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "jpg"
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension(ext)
            try data.write(to: url, options: .atomic)
            return ImportedMedia(url: url, kind: .photo, duration: 5)
        }

        throw MediaImportError.unsupportedAsset
    }
}

struct MovieTransfer: Transferable {
    let url: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { received in
            let target = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension(received.file.pathExtension.isEmpty ? "mov" : received.file.pathExtension)
            try FileManager.default.copyItem(at: received.file, to: target)
            return MovieTransfer(url: target)
        }
    }
}
