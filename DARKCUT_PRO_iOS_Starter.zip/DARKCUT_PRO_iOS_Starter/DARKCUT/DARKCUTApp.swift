import SwiftUI

@main
struct DARKCUTApp: App {
    @StateObject private var project = EditorProject()

    var body: some Scene {
        WindowGroup {
            EditorView()
                .environmentObject(project)
                .preferredColorScheme(.dark)
        }
    }
}
