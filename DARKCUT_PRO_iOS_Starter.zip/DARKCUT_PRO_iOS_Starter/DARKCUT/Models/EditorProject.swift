import Foundation
import SwiftUI

@MainActor
final class EditorProject: ObservableObject {
    @Published var clips: [EditorClip] = []
    @Published var selectedClipID: UUID?
    @Published var playhead: Double = 0
    @Published var projectName = "Новый проект"
    @Published var aspectRatio = "9:16"

    var duration: Double {
        clips.map(\.timelineEnd).max() ?? 0
    }

    var selectedClip: EditorClip? {
        clips.first { $0.id == selectedClipID }
    }

    func add(_ clip: EditorClip) {
        clips.append(clip)
        selectedClipID = clip.id
    }

    func updateSelected(_ transform: (inout EditorClip) -> Void) {
        guard let id = selectedClipID,
              let index = clips.firstIndex(where: { $0.id == id }) else { return }
        transform(&clips[index])
    }

    func deleteSelected() {
        guard let id = selectedClipID else { return }
        clips.removeAll { $0.id == id }
        selectedClipID = nil
    }

    func splitSelectedAtPlayhead() {
        guard let id = selectedClipID,
              let index = clips.firstIndex(where: { $0.id == id }) else { return }
        let original = clips[index]
        let localTime = (playhead - original.timelineStart) * original.speed
        guard localTime > 0.05, localTime < original.sourceDuration - 0.05 else { return }

        var left = original
        var right = original
        left.sourceOut = original.sourceIn + localTime
        right.id = UUID()
        right.sourceIn = left.sourceOut
        right.timelineStart = playhead
        clips[index] = left
        clips.insert(right, at: index + 1)
        selectedClipID = right.id
    }
}
