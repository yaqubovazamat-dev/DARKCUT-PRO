import Foundation

enum ClipKind: String, CaseIterable, Identifiable {
    case video, photo, audio, text
    var id: String { rawValue }
}

struct EditorClip: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var kind: ClipKind
    var sourceURL: URL?
    var timelineStart: Double
    var sourceIn: Double
    var sourceOut: Double
    var speed: Double = 1
    var volume: Double = 1
    var filterName: String = "Original"
    var text: String = ""

    var sourceDuration: Double { max(0, sourceOut - sourceIn) }
    var timelineDuration: Double { sourceDuration / max(speed, 0.01) }
    var timelineEnd: Double { timelineStart + timelineDuration }
}
